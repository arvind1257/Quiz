<?php
if(!isset($_SESSION["uid"]) || !isset($_SESSION["uname"]) || !isset($_SESSION["utype"]))
{
    
    header("Location: index.php");
    exit();
}
else
{
    $con = mysqli_connect("sql100.epizy.com","epiz_33012247","EDf2DUCFLtaXCtz","epiz_33012247_quiz");
    $uid = $_SESSION["uid"];
    $uname = $_SESSION["uname"];
    $utype = $_SESSION["utype"];
}